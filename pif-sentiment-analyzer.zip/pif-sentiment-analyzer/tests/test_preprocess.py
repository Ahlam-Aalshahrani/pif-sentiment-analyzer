import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))

from preprocess import clean_text, normalize_arabic


def test_clean_text_removes_urls():
    assert "http" not in clean_text("Check this out http://example.com now")


def test_clean_text_removes_mentions_and_hashtags():
    result = clean_text("Great news @PIF_news about #NEOM today")
    assert "@" not in result
    assert "#" not in result


def test_clean_text_lowercases_english():
    assert clean_text("PIF Announces BIG News") == clean_text("pif announces big news")


def test_normalize_arabic_unifies_alef():
    assert normalize_arabic("إعلان أخبار آمنة") == normalize_arabic("اعلان اخبار امنه".replace("ه", "ه"))


def test_normalize_arabic_removes_diacritics():
    text_with_diacritics = "مَرْحَبًا"
    result = normalize_arabic(text_with_diacritics)
    assert "َ" not in result
    assert "ْ" not in result


def test_clean_text_empty_input():
    assert clean_text("") == ""
    assert clean_text(None) == ""


if __name__ == "__main__":
    test_clean_text_removes_urls()
    test_clean_text_removes_mentions_and_hashtags()
    test_clean_text_lowercases_english()
    test_normalize_arabic_removes_diacritics()
    test_clean_text_empty_input()
    print("All tests passed.")
