"""
Streamlit dashboard for the PIF Sentiment Analyzer.

Run with:
    streamlit run src/app.py
"""

import os
import sys

import pandas as pd
import streamlit as st

sys.path.append(os.path.dirname(__file__))
from predict import SentimentPredictor
from preprocess import clean_text

st.set_page_config(page_title="PIF Sentiment Analyzer", page_icon="📊", layout="wide")

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")

st.title("📊 PIF & Saudi Mega-Projects Sentiment Analyzer")
st.markdown(
    "Analyze the sentiment of news headlines and social media posts about "
    "PIF-backed projects (NEOM, Qiddiya, Red Sea, Diriyah, etc.) — supports "
    "**Arabic** and **English**."
)


@st.cache_resource
def load_predictor():
    try:
        return SentimentPredictor(MODEL_DIR)
    except FileNotFoundError:
        return None


predictor = load_predictor()

if predictor is None:
    st.error(
        "⚠️ No trained model found. Please run `python src/train.py` first "
        "to train the model on the sample dataset."
    )
    st.stop()

tab1, tab2 = st.tabs(["🔍 Single Prediction", "📁 Batch Analysis (CSV)"])

with tab1:
    st.subheader("Analyze a single headline")
    default_text = "PIF announces record $20 billion investment in green hydrogen"
    text_input = st.text_area("Enter headline or post text:", value=default_text, height=100)

    if st.button("Analyze Sentiment", type="primary"):
        if text_input.strip():
            result = predictor.predict(text_input)
            sentiment = result["sentiment"]

            colors = {"positive": "🟢", "negative": "🔴", "neutral": "🟡"}
            st.markdown(f"### {colors.get(sentiment, '⚪')} Sentiment: **{sentiment.upper()}**")

            if "probabilities" in result:
                prob_df = pd.DataFrame(
                    result["probabilities"].items(), columns=["Sentiment", "Probability"]
                )
                st.bar_chart(prob_df.set_index("Sentiment"))
        else:
            st.warning("Please enter some text to analyze.")

with tab2:
    st.subheader("Upload a CSV of headlines")
    st.caption("CSV must contain a column named `text`.")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])

    if uploaded is not None:
        df = pd.read_csv(uploaded)
        if "text" not in df.columns:
            st.error("CSV must contain a 'text' column.")
        else:
            with st.spinner("Analyzing..."):
                results = predictor.predict_batch(df["text"].tolist())
                results_df = pd.DataFrame(results)

            st.success(f"Analyzed {len(results_df)} entries.")
            st.dataframe(results_df[["text", "sentiment"]], use_container_width=True)

            st.subheader("Sentiment Distribution")
            counts = results_df["sentiment"].value_counts()
            st.bar_chart(counts)

            csv = results_df.to_csv(index=False).encode("utf-8-sig")
            st.download_button(
                "⬇️ Download Results as CSV",
                data=csv,
                file_name="sentiment_results.csv",
                mime="text/csv",
            )

st.markdown("---")
st.caption(
    "Built with TF-IDF + scikit-learn · Supports Arabic & English · "
    "Demo project for Saudi mega-project / PIF news sentiment tracking."
)
