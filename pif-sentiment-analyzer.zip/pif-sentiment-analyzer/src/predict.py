"""
Load trained TF-IDF + classifier and predict sentiment on new headlines.

Usage:
    python src/predict.py --text "PIF announces new investment in NEOM"
"""

import argparse
import os
import sys

import joblib

sys.path.append(os.path.dirname(__file__))
from preprocess import clean_text


class SentimentPredictor:
    def __init__(self, model_dir: str = "models/"):
        vec_path = os.path.join(model_dir, "tfidf_vectorizer.joblib")
        clf_path = os.path.join(model_dir, "sentiment_classifier.joblib")

        if not os.path.exists(vec_path) or not os.path.exists(clf_path):
            raise FileNotFoundError(
                f"Model files not found in {model_dir}. Run src/train.py first."
            )

        self.vectorizer = joblib.load(vec_path)
        self.clf = joblib.load(clf_path)

    def predict(self, text: str) -> dict:
        cleaned = clean_text(text)
        vec = self.vectorizer.transform([cleaned])
        label = self.clf.predict(vec)[0]

        result = {"text": text, "sentiment": label}

        if hasattr(self.clf, "predict_proba"):
            probs = self.clf.predict_proba(vec)[0]
            result["confidence"] = round(float(max(probs)), 4)
            result["probabilities"] = {
                cls: round(float(p), 4)
                for cls, p in zip(self.clf.classes_, probs)
            }

        return result

    def predict_batch(self, texts: list) -> list:
        return [self.predict(t) for t in texts]


def main():
    parser = argparse.ArgumentParser(description="Predict PIF headline sentiment")
    parser.add_argument("--text", required=True, help="Headline text to classify")
    parser.add_argument("--model-dir", default="models/")
    args = parser.parse_args()

    predictor = SentimentPredictor(args.model_dir)
    result = predictor.predict(args.text)

    print(f"\nText:       {result['text']}")
    print(f"Sentiment:  {result['sentiment'].upper()}")
    if "confidence" in result:
        print(f"Confidence: {result['confidence']:.2%}")
        print("Probabilities:")
        for cls, p in result["probabilities"].items():
            print(f"  {cls:10s}: {p:.2%}")


if __name__ == "__main__":
    main()
