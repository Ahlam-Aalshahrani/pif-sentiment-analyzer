"""
Text preprocessing utilities for Arabic and English text.
Handles normalization, cleaning, and tokenization prep for TF-IDF vectorization.
"""

import re
import string


ARABIC_DIACRITICS = re.compile(r"""
    ّ    | # Shadda
    َ    | # Fatha
    ً    | # Fathatan
    ُ    | # Damma
    ٌ    | # Dammatan
    ِ    | # Kasra
    ٍ    | # Kasratan
    ْ    | # Sukun
    ـ     # Tatweel
""", re.VERBOSE)


def normalize_arabic(text: str) -> str:
    """Normalize Arabic text: remove diacritics, normalize letter forms."""
    text = ARABIC_DIACRITICS.sub("", text)
    text = re.sub("[إأآا]", "ا", text)
    text = re.sub("ى", "ي", text)
    text = re.sub("ؤ", "ء", text)
    text = re.sub("ئ", "ء", text)
    text = re.sub("ة", "ه", text)
    return text


def clean_text(text: str) -> str:
    """
    Clean and normalize a piece of text (Arabic or English).
    - Lowercase (for English)
    - Remove URLs, mentions, hashtags symbols
    - Remove punctuation
    - Normalize Arabic characters
    - Collapse whitespace
    """
    if not isinstance(text, str):
        return ""

    text = text.lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"@\w+", " ", text)
    text = re.sub(r"#", " ", text)
    text = normalize_arabic(text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"[^\w\s\u0600-\u06FF]", " ", text)
    text = re.sub(r"\d+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def preprocess_dataframe(df, text_column: str = "text", output_column: str = "clean_text"):
    """Apply clean_text to a dataframe column and return the dataframe with a new column."""
    df = df.copy()
    df[output_column] = df[text_column].apply(clean_text)
    return df


if __name__ == "__main__":
    samples = [
        "PIF announces record $20 billion investment surge!",
        "يعلن صندوق الاستثمارات العامة عن استثمارات ضخمة جديدة في الطاقة المتجددة",
    ]
    for s in samples:
        print(f"Original: {s}")
        print(f"Cleaned:  {clean_text(s)}\n")
