"""
Train a TF-IDF + Logistic Regression sentiment classifier on PIF/Saudi
mega-project related headlines (Arabic + English).

Usage:
    python src/train.py --data data/pif_sentiment_sample.csv --out models/
"""

import argparse
import os
import sys

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.svm import LinearSVC

sys.path.append(os.path.dirname(__file__))
from preprocess import preprocess_dataframe


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"text", "sentiment"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV must contain columns: {required}")
    return df


def build_pipeline(model_type: str = "logreg"):
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        min_df=1,
        max_df=0.95,
        sublinear_tf=True,
    )

    if model_type == "svm":
        clf = LinearSVC(class_weight="balanced", random_state=42)
    else:
        clf = LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=42
        )

    return vectorizer, clf


def train(data_path: str, out_dir: str, model_type: str = "logreg", test_size: float = 0.2):
    os.makedirs(out_dir, exist_ok=True)

    print(f"Loading data from {data_path} ...")
    df = load_data(data_path)
    df = preprocess_dataframe(df, text_column="text", output_column="clean_text")

    X = df["clean_text"]
    y = df["sentiment"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )

    vectorizer, clf = build_pipeline(model_type)

    print("Fitting TF-IDF vectorizer ...")
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    print(f"Training {model_type} classifier ...")
    clf.fit(X_train_vec, y_train)

    y_pred = clf.predict(X_test_vec)
    acc = accuracy_score(y_test, y_pred)

    print(f"\nTest Accuracy: {acc:.4f}\n")
    print("Classification Report:")
    print(classification_report(y_test, y_pred, zero_division=0))
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred, labels=sorted(y.unique())))

    vec_path = os.path.join(out_dir, "tfidf_vectorizer.joblib")
    clf_path = os.path.join(out_dir, "sentiment_classifier.joblib")
    joblib.dump(vectorizer, vec_path)
    joblib.dump(clf, clf_path)

    print(f"\nSaved vectorizer -> {vec_path}")
    print(f"Saved classifier -> {clf_path}")

    return acc


def main():
    parser = argparse.ArgumentParser(description="Train PIF sentiment classifier")
    parser.add_argument("--data", default="data/pif_sentiment_sample.csv")
    parser.add_argument("--out", default="models/")
    parser.add_argument("--model", default="logreg", choices=["logreg", "svm"])
    parser.add_argument("--test-size", type=float, default=0.2)
    args = parser.parse_args()

    train(args.data, args.out, model_type=args.model, test_size=args.test_size)


if __name__ == "__main__":
    main()
